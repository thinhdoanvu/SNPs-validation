

sigma <- scan('results4pops_K10.sigma')

plot(sigma, xlab = 'K', ylab = 'eigenvalues', pch = 18, cex = 2)
