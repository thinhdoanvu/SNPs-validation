/*
   FastPCAdapt FastPCAdapt.c
   Copyright (C) 2014 Nicolas Duforet Frebourg

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "../src/Data.h"
#include "../src/matrix.h"
#include "../src/linAlgebra.h"
#include "Data__f.h"
#include "stat.h"

#define MAXFILE 64

int FastPCAdapt(int argc, char* argv[]){
    printf("Last Updated On February, 11th, 2016.\n");
    printf("*************************************\n");

    FILE *GenoFile;
	char **GenoFileName = malloc(sizeof(char)*MAXFILE);
	char *OutputFileName = malloc(sizeof(char)*256);
	char *subSampleName = malloc(sizeof(char)*256);
	int nSNP, nIND, K = 2, runSVD = 0, tmp, nF, nfile, haploid = 1;
	int na, err = 0, sc = 1, i;
	double *Genotypes, *U, *V, *Sigma, *SNPSd, *Cov, *mAF, *miss, prop = .01, min_AF = 0; 
	int nSNP_file[MAXFILE];

	/* handleparams: gestion des paramètres */
	if (argc > 2){Welcome__f(0); if(handleParams__f(argc, argv, &nSNP, &nIND, &Genotypes, GenoFileName, &OutputFileName, &K, &runSVD, &subSampleName, &sc, &nfile, nSNP_file, &prop, &haploid, &min_AF)) return 0;} else {Welcome__f(1); return 0;}


	nF = nIND > nSNP ? nSNP : nIND;
	nF = K;
	/* Allocation de mémoire */
    initializeVariables__f(&U, &Sigma, &V, &SNPSd, &Cov, &miss, &mAF, nF, nSNP, nIND);
    if(!strcmp(OutputFileName, "")) OutputFileName = "FastPCAdapt_output";
    printf("results in files %s*\n", OutputFileName);

	/* Calcule la matrice de covariance nxn */
	err = Cov_line(Cov, SNPSd, nSNP, nSNP_file, nIND, sc, GenoFileName, nfile, haploid, min_AF);
	if (err) return 0;
    printf("Covariance estimated\n");

	/* diagonalisation de la matrice nxn */
	/* renvoie la racine des valeurs propres dans Sigma */
	/* renvoie la matrice V (n x K) */
	diagonalize(Cov, nIND, K, Sigma, V);
    /* V is a nxK matrix */
	/* calcule la matrice U (K x p) */
	err = Load_line(U, Sigma, V, miss, mAF, nSNP, nSNP_file, K, nIND, sc, GenoFileName, nfile, haploid, min_AF);
	if (err) return 0;
    printf("loadings computed\n");
    
    /* Linear regression */
    int i6;
    double *Z,*Ypred, *tV, *residuals;
    Z = malloc(sizeof(double)*nSNP*K);
    Ypred = malloc(sizeof(double)*nIND);
    tV = calloc(K*nIND, sizeof(double));
    for (i6 = 0;i6<(K*nIND);i6++){
        tV[i6] = V[i6];
    }
    tr(tV,nIND,K);
    residuals = malloc(sizeof(double)*nSNP);

    FILE *GenoFile2;
    int i2, ii2, j2, na2, na_tot2 = 0, file2, snp_count2 = 0, low_AF_tot2 = 0, ax;
    int *missing;
    double var2, mean2;
    double *Geno2 = calloc(nIND, sizeof(double));
    
    for(file2=0; file2<nfile; file2++){
        if((GenoFile2 = fopen(GenoFileName[file2], "r")) == NULL){
            printf("Error, invalid input file\n");
            return 1;
        }
        
        for (i2=0; i2<nSNP_file[file2]; i2++){
            ii2 = i2 + snp_count2;
            na2 = get_row(Geno2, GenoFile2, nIND, &mean2, &var2, 0, 1, haploid, min_AF, &low_AF_tot2);
            if (na2 > 0){printf("Locus number %i has %i missing values.\n",ii2,na2);}
            miss[ii2] = na2;
            mAF[ii2] = mean2;
            prodMatrix(Geno2, V, (Z + K*(ii2)), 1, nIND, nIND, K);
            prodMatrix((Z+K*(ii2)),tV,Ypred,1,K,K,nIND);
            for (ax=0;ax<nIND;ax++){
                residuals[ii2] += (Geno2[ax]-Ypred[ax])*(Geno2[ax]-Ypred[ax]);
            }
            if ((nIND-K-na2<=0) || (mean2 < min_AF)){
                residuals[ii2] = 0.0;
            } else {
                residuals[ii2] /= (double) nIND-K-na2;
            }
        }        
        snp_count2 += nSNP_file[file2];
        fclose(GenoFile2);
    }
    FILE *zFile;
    char *fileZ = malloc(sizeof(char)*256);
    strcpy(fileZ, OutputFileName);
    strcat(fileZ, ".zscores");
    printf("Opening file %s...\n", fileZ);
    if((zFile = fopen(fileZ, "w")) == NULL) printf("ERROR, unable to open %s\n", fileZ);
    int i5,j5;
    for (i5=0; i5<nSNP; i5++){
        for (j5=0; j5<nF; j5++){
            if (residuals[i5]==0.0){
                fprintf(zFile, "NA ");
            } else {
                fprintf(zFile, "%f ", Z[i5*nF + j5]/sqrt(residuals[i5]));
            }
        }
        fprintf(zFile, "\n");
    }
    fclose(zFile);
    
	/* now we refer to V as tV, the K * nIND matrix */
    
	tr(V, nIND, K);

	/* Calcule les stats de l'ACP sur les loadings */
    getstat(U, Sigma, V, SNPSd, miss, mAF, nSNP, K, nIND, nF, sc, nSNP_file, GenoFileName, OutputFileName, nfile, prop);
    writeMatrix__f(U, Sigma, V, nSNP, K, nIND, nF, OutputFileName);

	free(miss);
	free(mAF);
	free(Cov);
	return 0;

}
