#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "../src/Data.h"
#include "Data__f.h"
#include "../src/linAlgebra.h"
#include "../src/matrix.h"
#include "stat.h"

#define MAXFILE 64

//FastPCAdapt
//main function of the fast version
int FastPCAdapt(int argc, char* argv[]);

